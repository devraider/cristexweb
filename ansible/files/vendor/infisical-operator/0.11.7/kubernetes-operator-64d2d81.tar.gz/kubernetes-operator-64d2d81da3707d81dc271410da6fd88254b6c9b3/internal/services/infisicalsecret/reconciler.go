package infisicalsecret

import (
	"bytes"
	"context"
	"errors"
	"fmt"
	"maps"
	"net/http"
	"sort"
	"strings"
	tpl "text/template"

	"github.com/Infisical/infisical/k8-operator/api/v1alpha1"
	"github.com/Infisical/infisical/k8-operator/internal/api"
	"github.com/Infisical/infisical/k8-operator/internal/config"
	"github.com/Infisical/infisical/k8-operator/internal/constants"
	"github.com/Infisical/infisical/k8-operator/internal/crypto"
	"github.com/Infisical/infisical/k8-operator/internal/model"
	"github.com/Infisical/infisical/k8-operator/internal/template"
	"github.com/Infisical/infisical/k8-operator/internal/util"
	"github.com/Infisical/infisical/k8-operator/internal/util/sse"
	"github.com/go-logr/logr"

	"k8s.io/apimachinery/pkg/runtime"
	"k8s.io/apimachinery/pkg/types"
	"sigs.k8s.io/controller-runtime/pkg/client"
	"sigs.k8s.io/controller-runtime/pkg/event"

	infisicalSdk "github.com/infisical/go-sdk"
	corev1 "k8s.io/api/core/v1"
	k8Errors "k8s.io/apimachinery/pkg/api/errors"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	ctrl "sigs.k8s.io/controller-runtime"
)

const FINALIZER_NAME = "secrets.finalizers.infisical.com"

var SYSTEM_PREFIXES = []string{"kubectl.kubernetes.io/", "kubernetes.io/", "k8s.io/", "helm.sh/"}

type InfisicalSecretReconciler struct {
	client.Client
	Scheme            *runtime.Scheme
	IsNamespaceScoped bool
}

func (r *InfisicalSecretReconciler) getInfisicalTokenFromKubeSecret(ctx context.Context, infisicalSecret v1alpha1.InfisicalSecret) (string, error) {
	// default to new secret ref structure
	secretName := infisicalSecret.Spec.Authentication.ServiceToken.ServiceTokenSecretReference.SecretName
	secretNamespace := infisicalSecret.Spec.Authentication.ServiceToken.ServiceTokenSecretReference.SecretNamespace
	// fall back to previous secret ref
	if secretName == "" {
		secretName = infisicalSecret.Spec.TokenSecretReference.SecretName
	}

	if secretNamespace == "" {
		secretNamespace = infisicalSecret.Spec.TokenSecretReference.SecretNamespace
	}

	tokenSecret, err := util.GetKubeSecretByNamespacedName(ctx, r.Client, types.NamespacedName{
		Namespace: secretNamespace,
		Name:      secretName,
	})

	if k8Errors.IsNotFound(err) || (secretNamespace == "" && secretName == "") {
		return "", nil
	}

	if err != nil {
		if util.IsNamespaceScopedError(err, r.IsNamespaceScoped) {
			return "", fmt.Errorf("unable to fetch Kubernetes CA certificate secret. Your Operator installation is namespace scoped, and cannot read secrets outside of the namespace it is installed in. Please ensure the CA certificate secret is in the same namespace as the operator. [err=%v]", err)
		}
		return "", fmt.Errorf("failed to read Infisical token secret from secret named [%s] in namespace [%s]: with error [%w]", infisicalSecret.Spec.TokenSecretReference.SecretName, infisicalSecret.Spec.TokenSecretReference.SecretNamespace, err)
	}

	infisicalServiceToken := tokenSecret.Data[constants.INFISICAL_TOKEN_SECRET_KEY_NAME]

	return strings.Replace(string(infisicalServiceToken), " ", "", -1), nil
}

// Fetches service account credentials from a Kubernetes secret specified in the infisicalSecret object, extracts the access key, public key, and private key from the secret, and returns them as a ServiceAccountCredentials object.
// If any keys are missing or an error occurs, returns an empty object or an error object, respectively.
func (r *InfisicalSecretReconciler) getInfisicalServiceAccountCredentialsFromKubeSecret(ctx context.Context, infisicalSecret v1alpha1.InfisicalSecret) (serviceAccountDetails model.ServiceAccountDetails, err error) {

	secretNamespace := infisicalSecret.Spec.Authentication.ServiceAccount.ServiceAccountSecretReference.SecretNamespace
	secretName := infisicalSecret.Spec.Authentication.ServiceAccount.ServiceAccountSecretReference.SecretName

	serviceAccountCredsFromKubeSecret, err := util.GetKubeSecretByNamespacedName(ctx, r.Client, types.NamespacedName{
		Namespace: secretNamespace,
		Name:      secretName,
	})

	if k8Errors.IsNotFound(err) || (secretNamespace == "" && secretName == "") {
		return model.ServiceAccountDetails{}, nil
	}

	if err != nil {
		if util.IsNamespaceScopedError(err, r.IsNamespaceScoped) {
			return model.ServiceAccountDetails{}, fmt.Errorf("unable to fetch Kubernetes service account credentials secret. Your Operator installation is namespace scoped, and cannot read secrets outside of the namespace it is installed in. Please ensure the service account credentials secret is in the same namespace as the operator. [err=%v]", err)
		}
		return model.ServiceAccountDetails{}, fmt.Errorf("something went wrong when fetching your service account credentials [err=%s]", err)
	}

	accessKeyFromSecret := serviceAccountCredsFromKubeSecret.Data[constants.SERVICE_ACCOUNT_ACCESS_KEY]
	publicKeyFromSecret := serviceAccountCredsFromKubeSecret.Data[constants.SERVICE_ACCOUNT_PUBLIC_KEY]
	privateKeyFromSecret := serviceAccountCredsFromKubeSecret.Data[constants.SERVICE_ACCOUNT_PRIVATE_KEY]

	if accessKeyFromSecret == nil || publicKeyFromSecret == nil || privateKeyFromSecret == nil {
		return model.ServiceAccountDetails{}, nil
	}

	return model.ServiceAccountDetails{AccessKey: string(accessKeyFromSecret), PrivateKey: string(privateKeyFromSecret), PublicKey: string(publicKeyFromSecret)}, nil
}

func convertBinaryToStringMap(binaryMap map[string][]byte) map[string]string {
	stringMap := make(map[string]string)
	for k, v := range binaryMap {
		stringMap[k] = string(v)
	}
	return stringMap
}

func (r *InfisicalSecretReconciler) createInfisicalManagedKubeResource(ctx context.Context, logger logr.Logger, infisicalSecret v1alpha1.InfisicalSecret, managedSecretReferenceInterface interface{}, secretsFromAPI []model.SingleEnvironmentVariable, resourceType constants.ManagedKubeResourceType) error {
	plainProcessedSecrets := make(map[string][]byte)

	var managedTemplateData *v1alpha1.SecretTemplate

	if resourceType == constants.MANAGED_KUBE_RESOURCE_TYPE_SECRET {
		managedTemplateData = managedSecretReferenceInterface.(v1alpha1.ManagedKubeSecretConfig).Template
	} else if resourceType == constants.MANAGED_KUBE_RESOURCE_TYPE_CONFIG_MAP {
		managedTemplateData = managedSecretReferenceInterface.(v1alpha1.ManagedKubeConfigMapConfig).Template
	}

	if managedTemplateData == nil || managedTemplateData.IncludeAllSecrets {
		for _, secret := range secretsFromAPI {
			plainProcessedSecrets[secret.Key] = []byte(secret.Value) // plain process
		}
	}

	if managedTemplateData != nil {
		secretKeyValue := make(map[string]model.SecretTemplateOptions)
		for _, secret := range secretsFromAPI {
			secretKeyValue[secret.Key] = model.SecretTemplateOptions{
				Value:      secret.Value,
				SecretPath: secret.SecretPath,
			}
		}

		for templateKey, userTemplate := range managedTemplateData.Data {
			tmpl, err := tpl.New("secret-templates").Funcs(template.GetTemplateFunctions()).Parse(userTemplate)
			if err != nil {
				return fmt.Errorf("unable to compile template: %s [err=%v]", templateKey, err)
			}

			buf := bytes.NewBuffer(nil)
			err = tmpl.Execute(buf, secretKeyValue)
			if err != nil {
				return fmt.Errorf("unable to execute template: %s [err=%v]", templateKey, err)
			}
			plainProcessedSecrets[templateKey] = buf.Bytes()
		}
	}

	// Determine labels and annotations for the managed resource
	labels := map[string]string{}
	annotations := map[string]string{}

	if managedTemplateData != nil && managedTemplateData.Metadata != nil {
		// Use template metadata directly
		for k, v := range managedTemplateData.Metadata.Labels {
			labels[k] = v
		}
		for k, v := range managedTemplateData.Metadata.Annotations {
			annotations[k] = v
		}
	} else {
		// Fall back to copying labels and annotations from InfisicalSecret CRD
		for k, v := range infisicalSecret.Labels {
			labels[k] = v
		}
		for k, v := range infisicalSecret.Annotations {
			isSystem := false
			for _, prefix := range SYSTEM_PREFIXES {
				if strings.HasPrefix(k, prefix) {
					isSystem = true
					break
				}
			}
			if !isSystem {
				annotations[k] = v
			}
		}

		// Track which labels and annotations we manage (for proper cleanup on updates)
		managedLabelKeys := make(map[string]bool)
		for k := range infisicalSecret.Labels {
			managedLabelKeys[k] = true
		}
		managedAnnotationKeys := make(map[string]bool)
		for k := range infisicalSecret.Annotations {
			isSystem := false
			for _, prefix := range SYSTEM_PREFIXES {
				if strings.HasPrefix(k, prefix) {
					isSystem = true
					break
				}
			}
			if !isSystem {
				managedAnnotationKeys[k] = true
			}
		}
		annotations[constants.MANAGED_LABELS_ANNOTATION] = formatManagedKeys(managedLabelKeys)
		annotations[constants.MANAGED_ANNOTATIONS_ANNOTATION] = formatManagedKeys(managedAnnotationKeys)
	}

	if resourceType == constants.MANAGED_KUBE_RESOURCE_TYPE_SECRET {

		managedSecretReference := managedSecretReferenceInterface.(v1alpha1.ManagedKubeSecretConfig)

		annotations[constants.SECRET_VERSION_ANNOTATION] = crypto.ComputeRenderedEtag(plainProcessedSecrets)
		// create a new secret as specified by the managed secret spec of CRD
		newKubeSecretInstance := &corev1.Secret{
			ObjectMeta: metav1.ObjectMeta{
				Name:        managedSecretReference.SecretName,
				Namespace:   managedSecretReference.SecretNamespace,
				Annotations: annotations,
				Labels:      labels,
			},
			Type: corev1.SecretType(managedSecretReference.SecretType),
			Data: plainProcessedSecrets,
		}

		if managedSecretReference.CreationPolicy == "Owner" {
			// Set InfisicalSecret instance as the owner and controller of the managed secret
			err := ctrl.SetControllerReference(&infisicalSecret, newKubeSecretInstance, r.Scheme)
			if err != nil {
				return err
			}
		}

		err := r.Client.Create(ctx, newKubeSecretInstance)
		if err != nil {
			return fmt.Errorf("unable to create the managed Kubernetes secret : %w", err)
		}
		logger.Info(fmt.Sprintf("Successfully created a managed Kubernetes secret with your Infisical secrets. Type: %s", managedSecretReference.SecretType))
		return nil
	} else if resourceType == constants.MANAGED_KUBE_RESOURCE_TYPE_CONFIG_MAP {

		managedSecretReference := managedSecretReferenceInterface.(v1alpha1.ManagedKubeConfigMapConfig)

		// create a new config map as specified by the managed secret spec of CRD
		newKubeConfigMapInstance := &corev1.ConfigMap{
			ObjectMeta: metav1.ObjectMeta{
				Name:        managedSecretReference.ConfigMapName,
				Namespace:   managedSecretReference.ConfigMapNamespace,
				Annotations: annotations,
				Labels:      labels,
			},
			Data: convertBinaryToStringMap(plainProcessedSecrets),
		}

		if managedSecretReference.CreationPolicy == "Owner" {
			// Set InfisicalSecret instance as the owner and controller of the managed config map
			err := ctrl.SetControllerReference(&infisicalSecret, newKubeConfigMapInstance, r.Scheme)
			if err != nil {
				return err
			}
		}

		err := r.Client.Create(ctx, newKubeConfigMapInstance)
		if err != nil {
			return fmt.Errorf("unable to create the managed Kubernetes config map : %w", err)
		}
		logger.Info(fmt.Sprintf("Successfully created a managed Kubernetes config map with your Infisical secrets. Type: %s", managedSecretReference.ConfigMapName))
		return nil

	}
	return fmt.Errorf("invalid resource type")

}

func parseManagedKeys(value string) map[string]bool {
	managedKeys := make(map[string]bool)
	if value == "" {
		return managedKeys
	}
	keys := strings.Split(value, ",")
	for _, key := range keys {
		key = strings.TrimSpace(key)
		if key != "" {
			managedKeys[key] = true
		}
	}
	return managedKeys
}

func formatManagedKeys(keys map[string]bool) string {
	if len(keys) == 0 {
		return ""
	}
	keyList := make([]string, 0, len(keys))
	for k := range keys {
		keyList = append(keyList, k)
	}
	sort.Strings(keyList)
	return strings.Join(keyList, ",")
}

// syncLabelsAndAnnotations syncs labels and annotations to the managed resource.
// If templateMetadata is provided, it uses those values directly instead of copying from the InfisicalSecret CRD.
// When using template metadata, we simply replace all labels/annotations with the template values.
// When not using template metadata, we use the existing tracking mechanism to manage labels/annotations from the CRD.
func (r *InfisicalSecretReconciler) syncLabelsAndAnnotations(infisicalSecret v1alpha1.InfisicalSecret, existingAnnotations map[string]string, existingLabels map[string]string, templateMetadata *v1alpha1.SecretTemplateMetadata) (map[string]string, map[string]string) {
	// If template metadata is provided, use it directly
	if templateMetadata != nil {
		newLabels := make(map[string]string)
		for k, v := range templateMetadata.Labels {
			newLabels[k] = v
		}

		newAnnotations := make(map[string]string)
		// Preserve system annotations
		for k, v := range existingAnnotations {
			isSystem := false
			for _, prefix := range SYSTEM_PREFIXES {
				if strings.HasPrefix(k, prefix) {
					isSystem = true
					break
				}
			}
			if isSystem || k == constants.SECRET_VERSION_ANNOTATION {
				newAnnotations[k] = v
			}
		}
		for k, v := range templateMetadata.Annotations {
			newAnnotations[k] = v
		}

		return newAnnotations, newLabels
	}

	// Fall back to existing behavior: sync from CRD with tracking
	previouslyManagedLabels := parseManagedKeys(existingAnnotations[constants.MANAGED_LABELS_ANNOTATION])
	previouslyManagedAnnotations := parseManagedKeys(existingAnnotations[constants.MANAGED_ANNOTATIONS_ANNOTATION])

	currentCrdLabelKeys := make(map[string]bool)
	for k := range infisicalSecret.Labels {
		currentCrdLabelKeys[k] = true
	}

	currentCrdAnnotationKeys := make(map[string]bool)
	for k := range infisicalSecret.Annotations {
		isSystem := false
		for _, prefix := range SYSTEM_PREFIXES {
			if strings.HasPrefix(k, prefix) {
				isSystem = true
				break
			}
		}
		if !isSystem {
			currentCrdAnnotationKeys[k] = true
		}
	}

	newLabels := make(map[string]string)
	for k, v := range existingLabels {
		if !previouslyManagedLabels[k] {
			newLabels[k] = v
		}
	}
	for k, v := range infisicalSecret.Labels {
		newLabels[k] = v
	}

	newAnnotations := make(map[string]string)
	for k, v := range existingAnnotations {
		isSystem := false
		for _, prefix := range SYSTEM_PREFIXES {
			if strings.HasPrefix(k, prefix) {
				isSystem = true
				break
			}
		}
		if isSystem || k == constants.SECRET_VERSION_ANNOTATION || k == constants.MANAGED_LABELS_ANNOTATION || k == constants.MANAGED_ANNOTATIONS_ANNOTATION {
			newAnnotations[k] = v
		} else if !previouslyManagedAnnotations[k] {
			newAnnotations[k] = v
		}
	}

	for k, v := range infisicalSecret.Annotations {
		isSystem := false
		for _, prefix := range SYSTEM_PREFIXES {
			if strings.HasPrefix(k, prefix) {
				isSystem = true
				break
			}
		}
		if !isSystem {
			newAnnotations[k] = v
		}
	}

	newAnnotations[constants.MANAGED_LABELS_ANNOTATION] = formatManagedKeys(currentCrdLabelKeys)
	newAnnotations[constants.MANAGED_ANNOTATIONS_ANNOTATION] = formatManagedKeys(currentCrdAnnotationKeys)

	return newAnnotations, newLabels
}

func (r *InfisicalSecretReconciler) updateInfisicalManagedKubeSecret(ctx context.Context, logger logr.Logger, infisicalSecret v1alpha1.InfisicalSecret, managedSecretReference v1alpha1.ManagedKubeSecretConfig, managedKubeSecret corev1.Secret, secretsFromAPI []model.SingleEnvironmentVariable) error {
	managedTemplateData := managedSecretReference.Template

	plainProcessedSecrets := make(map[string][]byte)
	if managedTemplateData == nil || managedTemplateData.IncludeAllSecrets {
		for _, secret := range secretsFromAPI {
			plainProcessedSecrets[secret.Key] = []byte(secret.Value)
		}
	}

	if managedTemplateData != nil {
		secretKeyValue := make(map[string]model.SecretTemplateOptions)
		for _, secret := range secretsFromAPI {
			secretKeyValue[secret.Key] = model.SecretTemplateOptions{
				Value:      secret.Value,
				SecretPath: secret.SecretPath,
			}
		}

		for templateKey, userTemplate := range managedTemplateData.Data {
			tmpl, err := tpl.New("secret-templates").Funcs(template.GetTemplateFunctions()).Parse(userTemplate)
			if err != nil {
				return fmt.Errorf("unable to compile template: %s [err=%v]", templateKey, err)
			}

			buf := bytes.NewBuffer(nil)
			err = tmpl.Execute(buf, secretKeyValue)
			if err != nil {
				return fmt.Errorf("unable to execute template: %s [err=%v]", templateKey, err)
			}
			plainProcessedSecrets[templateKey] = buf.Bytes()
		}
	}

	// Sync labels and annotations (uses template metadata if provided, otherwise falls back to CRD metadata)
	var templateMetadata *v1alpha1.SecretTemplateMetadata
	if managedTemplateData != nil {
		templateMetadata = managedTemplateData.Metadata
	}
	newAnnotations, newLabels := r.syncLabelsAndAnnotations(infisicalSecret, managedKubeSecret.ObjectMeta.Annotations, managedKubeSecret.ObjectMeta.Labels, templateMetadata)
	newAnnotations[constants.SECRET_VERSION_ANNOTATION] = crypto.ComputeRenderedEtag(plainProcessedSecrets)

	// Skip the apiserver write when the rendered output and metadata are unchanged. Without
	// this, a sibling-secret change in the same Infisical scope flips the server-side ETag,
	// which lands here as a 200, and an unconditional Update would bump the managed Secret's
	// resourceVersion and trigger auto-reload restarts on Deployments that don't actually
	// consume the changed key. See ENG-5058.
	if maps.EqualFunc(managedKubeSecret.Data, plainProcessedSecrets, bytes.Equal) &&
		maps.Equal(managedKubeSecret.ObjectMeta.Annotations, newAnnotations) &&
		maps.Equal(managedKubeSecret.ObjectMeta.Labels, newLabels) {
		logger.Info("Managed Kubernetes secret already up to date, skipping update")
		return nil
	}

	managedKubeSecret.ObjectMeta.Labels = newLabels
	managedKubeSecret.ObjectMeta.Annotations = newAnnotations
	managedKubeSecret.Data = plainProcessedSecrets

	err := r.Client.Update(ctx, &managedKubeSecret)
	if err != nil {
		return fmt.Errorf("unable to update Kubernetes secret because [%w]", err)
	}

	logger.Info("successfully updated managed Kubernetes secret")
	return nil
}

func (r *InfisicalSecretReconciler) updateInfisicalManagedConfigMap(ctx context.Context, logger logr.Logger, infisicalSecret v1alpha1.InfisicalSecret, managedConfigMapReference v1alpha1.ManagedKubeConfigMapConfig, managedConfigMap corev1.ConfigMap, secretsFromAPI []model.SingleEnvironmentVariable) error {
	managedTemplateData := managedConfigMapReference.Template

	plainProcessedSecrets := make(map[string][]byte)
	if managedTemplateData == nil || managedTemplateData.IncludeAllSecrets {
		for _, secret := range secretsFromAPI {
			plainProcessedSecrets[secret.Key] = []byte(secret.Value)
		}
	}

	if managedTemplateData != nil {
		secretKeyValue := make(map[string]model.SecretTemplateOptions)
		for _, secret := range secretsFromAPI {
			secretKeyValue[secret.Key] = model.SecretTemplateOptions{
				Value:      secret.Value,
				SecretPath: secret.SecretPath,
			}
		}

		for templateKey, userTemplate := range managedTemplateData.Data {
			tmpl, err := tpl.New("secret-templates").Funcs(template.GetTemplateFunctions()).Parse(userTemplate)
			if err != nil {
				return fmt.Errorf("unable to compile template: %s [err=%v]", templateKey, err)
			}

			buf := bytes.NewBuffer(nil)
			err = tmpl.Execute(buf, secretKeyValue)
			if err != nil {
				return fmt.Errorf("unable to execute template: %s [err=%v]", templateKey, err)
			}
			plainProcessedSecrets[templateKey] = buf.Bytes()
		}
	}

	// Sync labels and annotations (uses template metadata if provided, otherwise falls back to CRD metadata)
	var templateMetadata *v1alpha1.SecretTemplateMetadata
	if managedTemplateData != nil {
		templateMetadata = managedTemplateData.Metadata
	}
	newAnnotations, newLabels := r.syncLabelsAndAnnotations(infisicalSecret, managedConfigMap.ObjectMeta.Annotations, managedConfigMap.ObjectMeta.Labels, templateMetadata)
	newAnnotations[constants.SECRET_VERSION_ANNOTATION] = crypto.ComputeRenderedEtag(plainProcessedSecrets)

	newData := convertBinaryToStringMap(plainProcessedSecrets)

	if maps.Equal(managedConfigMap.Data, newData) &&
		maps.Equal(managedConfigMap.ObjectMeta.Annotations, newAnnotations) &&
		maps.Equal(managedConfigMap.ObjectMeta.Labels, newLabels) {
		logger.Info("Managed Kubernetes config map already up to date, skipping update")
		return nil
	}

	managedConfigMap.ObjectMeta.Labels = newLabels
	managedConfigMap.ObjectMeta.Annotations = newAnnotations
	managedConfigMap.Data = newData

	err := r.Client.Update(ctx, &managedConfigMap)
	if err != nil {
		return fmt.Errorf("unable to update Kubernetes config map because [%w]", err)
	}

	logger.Info("successfully updated managed Kubernetes config map")
	return nil
}

func (r *InfisicalSecretReconciler) fetchSecretsFromAPI(ctx context.Context, logger logr.Logger, authDetails util.AuthenticationDetails, infisicalClient infisicalSdk.InfisicalClientInterface, infisicalSecret v1alpha1.InfisicalSecret, ifNoneMatch string) (util.SecretsResult, error) {

	if authDetails.AuthStrategy == util.AuthStrategy.SERVICE_ACCOUNT { // Service Account // ! Legacy auth method
		serviceAccountCreds, err := r.getInfisicalServiceAccountCredentialsFromKubeSecret(ctx, infisicalSecret)
		if err != nil {
			return util.SecretsResult{}, fmt.Errorf("ReconcileInfisicalSecret: unable to get service account creds from kube secret [err=%s]", err)
		}

		result, err := util.GetPlainTextSecretsViaServiceAccount(infisicalClient, serviceAccountCreds, infisicalSecret.Spec.Authentication.ServiceAccount.ProjectId, infisicalSecret.Spec.Authentication.ServiceAccount.EnvironmentName, ifNoneMatch)
		if err != nil {
			return util.SecretsResult{}, fmt.Errorf("\nfailed to get secrets because [err=%v]", err)
		}

		if !result.NotModified {
			logger.Info("ReconcileInfisicalSecret: Fetched secrets via service account")
		}

		return result, nil

	} else if authDetails.AuthStrategy == util.AuthStrategy.SERVICE_TOKEN { // Service Tokens // ! Legacy / Deprecated auth method
		infisicalToken, err := r.getInfisicalTokenFromKubeSecret(ctx, infisicalSecret)
		if err != nil {
			return util.SecretsResult{}, fmt.Errorf("ReconcileInfisicalSecret: unable to get service token from kube secret [err=%s]", err)
		}

		envSlug := infisicalSecret.Spec.Authentication.ServiceToken.SecretsScope.EnvSlug
		secretsPath := infisicalSecret.Spec.Authentication.ServiceToken.SecretsScope.SecretsPath
		recursive := infisicalSecret.Spec.Authentication.ServiceToken.SecretsScope.Recursive

		result, err := util.GetPlainTextSecretsViaServiceToken(infisicalClient, infisicalToken, envSlug, secretsPath, recursive, ifNoneMatch)
		if err != nil {
			return util.SecretsResult{}, fmt.Errorf("\nfailed to get secrets because [err=%v]", err)
		}

		if !result.NotModified {
			logger.Info("ReconcileInfisicalSecret: Fetched secrets via [type=SERVICE_TOKEN]")
		}

		return result, nil

	} else if authDetails.IsMachineIdentityAuth { // * Machine Identity authentication, the SDK will be authenticated at this point
		if err := authDetails.MachineIdentityScope.ValidateScope(); err != nil {
			return util.SecretsResult{}, fmt.Errorf("invalid machine identity scope [err=%s]", err)
		}

		if authDetails.MachineIdentityScope.ProjectSlug != "" {
			projectId, err := util.ExtractProjectIdFromSlug(infisicalClient.Auth().GetAccessToken(), authDetails.MachineIdentityScope.ProjectSlug)

			logger.Info(fmt.Sprintf("ReconcileInfisicalSecret: Extracted project id from slug [projectId=%s] [projectSlug=%s]", projectId, authDetails.MachineIdentityScope.ProjectSlug))
			if err != nil {
				return util.SecretsResult{}, fmt.Errorf("unable to extract project id from slug [err=%s]", err)
			}

			authDetails.MachineIdentityScope.ProjectID = projectId
		}

		result, err := util.GetPlainTextSecretsViaMachineIdentity(infisicalClient, authDetails.MachineIdentityScope, ifNoneMatch)

		if err != nil {
			return util.SecretsResult{}, fmt.Errorf("\nfailed to get secrets because [err=%v]", err)
		}

		if !result.NotModified {
			if authDetails.MachineIdentityScope.SecretName != "" {
				logger.Info(fmt.Sprintf("ReconcileInfisicalSecret: Fetched secret via machine identity [type=%v] [secretName=%s]", authDetails.AuthStrategy, authDetails.MachineIdentityScope.SecretName))
			} else {
				logger.Info(fmt.Sprintf("ReconcileInfisicalSecret: Fetched secrets via machine identity [type=%v]", authDetails.AuthStrategy))
			}
		}
		return result, nil

	} else {
		return util.SecretsResult{}, errors.New("no authentication method provided. Please configure a authentication method then try again")
	}
}

func (r *InfisicalSecretReconciler) getResourceVariables(infisicalSecret v1alpha1.InfisicalSecret, resourceVariablesMap map[string]util.ResourceVariables) util.ResourceVariables {

	var resourceVariables util.ResourceVariables

	if _, ok := resourceVariablesMap[string(infisicalSecret.UID)]; !ok {

		ctx, cancel := context.WithCancel(context.Background())

		client := infisicalSdk.NewInfisicalClient(ctx, infisicalSdk.Config{
			SiteUrl:       config.API_HOST_URL,
			CaCertificate: config.API_CA_CERTIFICATE,
			UserAgent:     util.UserAgent(),
			LogWriter:     config.API_LOG_WRITER,
		})

		// SSE registry will be initialized lazily in OpenInstantUpdatesStream
		// when eventCh is available
		resourceVariablesMap[string(infisicalSecret.UID)] = util.ResourceVariables{
			InfisicalClient:  client,
			CancelCtx:        cancel,
			AuthDetails:      util.AuthenticationDetails{},
			ServerSentEvents: nil,
		}

		resourceVariables = resourceVariablesMap[string(infisicalSecret.UID)]

	} else {
		resourceVariables = resourceVariablesMap[string(infisicalSecret.UID)]
	}

	return resourceVariables
}

func (r *InfisicalSecretReconciler) updateResourceVariables(infisicalSecret v1alpha1.InfisicalSecret, resourceVariables util.ResourceVariables, resourceVariablesMap map[string]util.ResourceVariables) {
	resourceVariablesMap[string(infisicalSecret.UID)] = resourceVariables
}

func isOwnedByInfisicalSecret(obj client.Object, infisicalSecretUID types.UID) bool {
	for _, ownerRef := range obj.GetOwnerReferences() {
		if ownerRef.UID == infisicalSecretUID &&
			ownerRef.Kind == constants.INFISICAL_SECRET_KIND {
			return true
		}
	}
	return false
}

// Removes secrets and configmaps that are owned by the InfisicalSecret but are no longer referenced in the spec
// Best effort, don't fail reconciliation
func (r *InfisicalSecretReconciler) deleteUnreferencedOwnedResources(
	ctx context.Context,
	logger logr.Logger,
	infisicalSecret v1alpha1.InfisicalSecret,
	secretOwnerReferences map[string]bool,
	configMapOwnerReferences map[string]bool,
) {
	secretList := &corev1.SecretList{}
	if err := r.List(ctx, secretList, client.InNamespace(infisicalSecret.Namespace)); err != nil {
		logger.Error(err, "Failed to list secrets for cleanup")
		return
	}

	for _, secret := range secretList.Items {
		if isOwnedByInfisicalSecret(&secret, infisicalSecret.UID) {
			key := secret.Namespace + "/" + secret.Name
			if !secretOwnerReferences[key] {
				logger.Info("Deleting orphaned owned secret", "secret", key)
				if err := r.Delete(ctx, &secret); err != nil {
					logger.Error(err, "Failed to delete orphaned owned secret", "secret", key)
				}
			}
		}
	}

	configMapList := &corev1.ConfigMapList{}
	if err := r.List(ctx, configMapList, client.InNamespace(infisicalSecret.Namespace)); err != nil {
		logger.Error(err, "Failed to list configmaps for cleanup")
		return
	}

	for _, cm := range configMapList.Items {
		if isOwnedByInfisicalSecret(&cm, infisicalSecret.UID) {
			key := cm.Namespace + "/" + cm.Name
			if !configMapOwnerReferences[key] {
				logger.Info("Deleting orphaned owned configmap", "configmap", key)
				if err := r.Delete(ctx, &cm); err != nil {
					logger.Error(err, "Failed to delete orphaned owned configmap", "configmap", key)
				}
			}
		}
	}
}

func (r *InfisicalSecretReconciler) ReconcileInfisicalSecret(ctx context.Context, logger logr.Logger, infisicalSecret *v1alpha1.InfisicalSecret, managedKubeSecretReferences []v1alpha1.ManagedKubeSecretConfig, managedKubeConfigMapReferences []v1alpha1.ManagedKubeConfigMapConfig, resourceVariablesMap map[string]util.ResourceVariables) (int, error) {

	if infisicalSecret == nil {
		return 0, fmt.Errorf("infisicalSecret is nil")
	}

	resourceVariables := r.getResourceVariables(*infisicalSecret, resourceVariablesMap)
	infisicalClient := resourceVariables.InfisicalClient
	authDetails := resourceVariables.AuthDetails
	var err error

	if authDetails.AuthStrategy == "" {
		logger.Info("No authentication strategy found. Attempting to authenticate")
		authDetails, err = util.HandleAuthentication(ctx, util.SecretAuthInput{
			Secret: *infisicalSecret,
			Type:   util.SecretCrd.INFISICAL_SECRET,
		}, r.Client, infisicalClient, r.IsNamespaceScoped)

		r.SetInfisicalTokenLoadCondition(ctx, logger, infisicalSecret, authDetails.AuthStrategy, err)

		if err != nil {
			return 0, fmt.Errorf("unable to authenticate [err=%s]", err)
		}

		// Update the local resourceVariables so that the auth details are preserved when resourceVariables is written back to the map later in this function.
		resourceVariables.AuthDetails = authDetails
		r.updateResourceVariables(*infisicalSecret, resourceVariables, resourceVariablesMap)
	}

	previousETag := resourceVariables.ServerETag
	result, err := r.fetchSecretsFromAPI(ctx, logger, authDetails, infisicalClient, *infisicalSecret, previousETag)

	if err != nil {
		return 0, fmt.Errorf("failed to fetch secrets from API for managed secrets [err=%s]", err)
	}

	if result.NotModified {
		logger.Info("Secrets unchanged (server ETag match), skipping reconciliation")
		return resourceVariables.LastSecretsCount, nil
	}

	plainTextSecretsFromApi := result.Secrets
	secretsCount := len(plainTextSecretsFromApi)
	secretOwnerReferences := make(map[string]bool)

	if len(managedKubeSecretReferences) > 0 {
		for _, managedSecretReference := range managedKubeSecretReferences {
			if managedSecretReference.CreationPolicy == "Owner" {
				key := managedSecretReference.SecretNamespace + "/" + managedSecretReference.SecretName
				secretOwnerReferences[key] = true
			}
			// Look for managed secret by name and namespace
			managedKubeSecret, err := util.GetKubeSecretByNamespacedName(ctx, r.Client, types.NamespacedName{
				Name:      managedSecretReference.SecretName,
				Namespace: managedSecretReference.SecretNamespace,
			})

			if err != nil && !k8Errors.IsNotFound(err) {
				if util.IsNamespaceScopedError(err, r.IsNamespaceScoped) {
					return 0, fmt.Errorf("unable to fetch Kubernetes secret. Your Operator installation is namespace scoped, and cannot read secrets outside of the namespace it is installed in. Please ensure the secret is in the same namespace as the operator. [err=%v]", err)
				}
				return 0, fmt.Errorf("something went wrong when fetching the managed Kubernetes secret [%w]", err)
			}

			if managedKubeSecret == nil {
				if err := r.createInfisicalManagedKubeResource(ctx, logger, *infisicalSecret, managedSecretReference, plainTextSecretsFromApi, constants.MANAGED_KUBE_RESOURCE_TYPE_SECRET); err != nil {
					return 0, fmt.Errorf("failed to create managed secret [err=%s]", err)
				}
			} else {
				if err := r.updateInfisicalManagedKubeSecret(ctx, logger, *infisicalSecret, managedSecretReference, *managedKubeSecret, plainTextSecretsFromApi); err != nil {
					return 0, fmt.Errorf("failed to update managed secret [err=%s]", err)
				}
			}
		}
	}

	configMapOwnerReferences := make(map[string]bool)

	if len(managedKubeConfigMapReferences) > 0 {
		for _, managedConfigMapReference := range managedKubeConfigMapReferences {
			if managedConfigMapReference.CreationPolicy == "Owner" {
				key := managedConfigMapReference.ConfigMapNamespace + "/" + managedConfigMapReference.ConfigMapName
				configMapOwnerReferences[key] = true
			}

			managedKubeConfigMap, err := util.GetKubeConfigMapByNamespacedName(ctx, r.Client, types.NamespacedName{
				Name:      managedConfigMapReference.ConfigMapName,
				Namespace: managedConfigMapReference.ConfigMapNamespace,
			})

			if err != nil && !k8Errors.IsNotFound(err) {
				if util.IsNamespaceScopedError(err, r.IsNamespaceScoped) {
					return 0, fmt.Errorf("unable to fetch Kubernetes config map. Your Operator installation is namespace scoped, and cannot read config maps outside of the namespace it is installed in. Please ensure the config map is in the same namespace as the operator. [err=%v]", err)
				}
				return 0, fmt.Errorf("something went wrong when fetching the managed Kubernetes config map [%w]", err)
			}

			if managedKubeConfigMap == nil {
				if err := r.createInfisicalManagedKubeResource(ctx, logger, *infisicalSecret, managedConfigMapReference, plainTextSecretsFromApi, constants.MANAGED_KUBE_RESOURCE_TYPE_CONFIG_MAP); err != nil {
					return 0, fmt.Errorf("failed to create managed config map [err=%s]", err)
				}
			} else {
				if err := r.updateInfisicalManagedConfigMap(ctx, logger, *infisicalSecret, managedConfigMapReference, *managedKubeConfigMap, plainTextSecretsFromApi); err != nil {
					return 0, fmt.Errorf("failed to update managed config map [err=%s]", err)
				}
			}

		}
	}

	r.deleteUnreferencedOwnedResources(ctx, logger, *infisicalSecret, secretOwnerReferences, configMapOwnerReferences)

	if result.ETag != "" {
		resourceVariables.ServerETag = result.ETag
	}
	resourceVariables.LastSecretsCount = secretsCount
	r.updateResourceVariables(*infisicalSecret, resourceVariables, resourceVariablesMap)

	return secretsCount, nil
}

func (r *InfisicalSecretReconciler) CloseInstantUpdatesStream(ctx context.Context, logger logr.Logger, infisicalSecret *v1alpha1.InfisicalSecret, resourceVariablesMap map[string]util.ResourceVariables) error {
	if infisicalSecret == nil {
		return fmt.Errorf("infisicalSecret is nil")
	}

	variables := r.getResourceVariables(*infisicalSecret, resourceVariablesMap)

	// Close SSE connection if it exists
	if variables.ServerSentEvents != nil {
		variables.ServerSentEvents.Close()
	}

	return nil
}

func (r *InfisicalSecretReconciler) OpenInstantUpdatesStream(ctx context.Context, logger logr.Logger, infisicalSecret *v1alpha1.InfisicalSecret, resourceVariablesMap map[string]util.ResourceVariables, eventCh chan<- event.TypedGenericEvent[client.Object]) error {
	if infisicalSecret == nil {
		return fmt.Errorf("infisicalSecret is nil")
	}

	variables := r.getResourceVariables(*infisicalSecret, resourceVariablesMap)

	identityScope := variables.AuthDetails.MachineIdentityScope

	if err := identityScope.ValidateScope(); err != nil {
		return fmt.Errorf("invalid machine identity scope [err=%s]", err)
	}

	infisicalClient := variables.InfisicalClient

	token := infisicalClient.Auth().GetAccessToken()

	// Resolve project ID from slug if needed
	resolvedProjectID := identityScope.ProjectID
	if identityScope.ProjectSlug != "" {
		projectId, err := util.ExtractProjectIdFromSlug(infisicalClient.Auth().GetAccessToken(), identityScope.ProjectSlug)
		if err != nil {
			return fmt.Errorf("unable to extract project id from slug [err=%s]", err)
		}
		resolvedProjectID = projectId
	}

	// Build secrets path with recursive suffix if needed
	secretsPath := identityScope.SecretsPath
	if identityScope.Recursive {
		if strings.HasSuffix(secretsPath, "/") {
			secretsPath += "**"
		} else {
			secretsPath += "/**"
		}
	}

	// Build current params for change detection
	currentParams := sse.SubscriptionParams{
		ProjectID:   resolvedProjectID,
		EnvSlug:     identityScope.EnvSlug,
		SecretsPath: secretsPath,
	}

	// Check if SSE registry exists, create if needed
	sseRegistry := variables.ServerSentEvents
	if sseRegistry == nil {
		// Create SSE registry with callbacks
		sseRegistry = sse.NewConnectionRegistry(
			// onEvent callback - triggers reconciliation
			func(ev sse.Event) {
				logger.Info("Received SSE Event", "event", ev.Event, "data", ev.Data)
				eventCh <- event.TypedGenericEvent[client.Object]{
					Object: infisicalSecret,
				}
			},
			// onError callback - log errors
			func(err error) {
				logger.Error(err, "SSE error occurred")
			},
			// onReconnect callback - triggers reconciliation after max retries
			func() {
				logger.Info("SSE max retries exceeded, triggering reconciliation")
				eventCh <- event.TypedGenericEvent[client.Object]{
					Object: infisicalSecret,
				}
			},
		)
		variables.ServerSentEvents = sseRegistry
	}

	// Check if params changed from existing connection
	if existingParams, ok := sseRegistry.GetParams(); ok {
		if existingParams.Equals(currentParams) {
			// Already connected with same params, check if connection is still valid
			if sseRegistry.IsConnected() {
				logger.Info("SSE connection already active with same params, reusing")
				return nil
			}
			// Connection is dead, will reconnect below
			logger.Info("SSE connection dead, reconnecting with same params")
		} else {
			// Params changed, log it
			logger.Info("SSE params changed, reconnecting",
				"old_project", existingParams.ProjectID,
				"new_project", currentParams.ProjectID,
				"old_env", existingParams.EnvSlug,
				"new_env", currentParams.EnvSlug,
				"old_path", existingParams.SecretsPath,
				"new_path", currentParams.SecretsPath)
		}
	}

	// Subscribe with the new params (will close old connection if needed)
	err := sseRegistry.SubscribeWithParams(currentParams, func() (*http.Response, error) {
		httpClient, err := util.CreateRestyClient(model.CreateRestyClientOptions{
			AccessToken: token,
			Headers: map[string]string{
				"Content-Type": "application/json",
				"Accept":       "text/event-stream",
				"Connection":   "keep-alive",
			},
		})

		if err != nil {
			return nil, fmt.Errorf("unable to create resty client. [err=%v]", err)
		}

		req, err := api.CallSubscribeProjectEvents(httpClient, currentParams.ProjectID, currentParams.SecretsPath, currentParams.EnvSlug)
		if err != nil {
			return nil, err
		}

		return req, nil
	})

	if err != nil {
		return fmt.Errorf("unable to connect sse [err=%s]", err)
	}

	// Update resource variables to persist the SSE registry
	r.updateResourceVariables(*infisicalSecret, variables, resourceVariablesMap)

	logger.Info("SSE connection established",
		"projectID", currentParams.ProjectID,
		"envSlug", currentParams.EnvSlug,
		"secretsPath", currentParams.SecretsPath)

	return nil
}
